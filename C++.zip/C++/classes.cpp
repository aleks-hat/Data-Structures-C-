#include <iostream>

class Point
{
    /*
        Java makes you label each attribute and method with an
        access specifier.  C++ allows you to group them.

        By convention, public items come first, then protected,
        then private.
    */
    public:
        /*
            You can use Java style and define the body of a method in the class
            as demonstrated in getX().  Or you can use C style.
            C style defines the body of the methods somewhere else.
            In this file, I define them below main.  In another example,
            I will define them in another file.
        */
        Point(); //default constructor
        Point(int, int); //parameterized constructor
        int getX()
        {
            return x;
        }
        int getY();
        void setX(int);
        void setY(int);
        static int getNum(){return num;} //LearnCpp.com 8.12 for more info
        ~Point();  //destructor, this runs when an object gets deleted
    private:
        int x;
        int y;
        /*
            Static variables are only created once for a family of classes.
            Every class of type Point will have access to the same num
            variable.  This allows us to count how many points we have.
            This isn't necessary, but it was a good place to demo it.

            There is some weird syntax below about how to initalize this.
        */
        static int num;
        int id; //hold which number the point is
};  //don't forget the ; here.  This is a common error for me.

/*
Syntax for initializing a static attribute.
This can only happen once, otherwise you get a compile error.
*/
int Point::num = 0;

int main()
{
    /*
        This is a call to the default constructor
        Notice that unlike Java, you don't have to use new
        You only have to use new in C++ when dealing with pointers
    */
    Point myPoint;

    //Call to the parameterized constructor
    Point newPoint(1, 1);

    myPoint.setX(42);
    myPoint.setY(99);

    std::cout << "Your point is: ";
    std::cout << myPoint.getX() << " " << myPoint.getY() << std::endl;
    std::cout << "There are: " << Point::getNum() << " points" << std::endl;
    return 0;
}

//The Point:: syntax says that the following function belongs to the Point class
Point::Point()
{
    x = 0;
    y = 0;
    id = num;
    num++;
}

Point::Point(int x, int y)
{
    this->x = x;  //"this" refers to the class variable, not the parameter
    this->y = y;  //notice that "this" is a pointer, so it uses -> not .
    id = num;
    num++;
}

//return types come before the class name
void Point::setX(int x)
{
    this->x = x;
}

void Point::setY(int y)
{
    this->y = y;
}

int Point::getY()
{
    return y;
}

Point::~Point()
{
    /*
        It's generally bad practice to print in your constructor
        or destructor, but to show you when this happens, I will do
        so here.
    */
    std::cout << "Destroying point " << id << std::endl;
    num--;
}
