//Demonstrates arrays and vectors

#include <iostream>
#include <vector> //dynamic arrays built for you!

//Note that 1D and 2D arrays are always passed by reference
//Vectors are pass by value unless you use the reference operator

/*
Passing a 1D array to a function isn't bad
*/
void print(int[], int);

/*
Passing a 2D array is more complicated.
We have to have the second parameter hard-coded here.
There are workarounds involving pointers if you want them.
*/
void print(int[][10], int);

//Vector print
void print(std::vector<int>);

int main()
{
    /*
    C++ allows us to create the length of an array at runtime
    */
    int length = 0;
    std::cout << "Enter the length of the array: " << std::endl;
    std::cin >> length;

    //declaring a 1D array
    int myArray[length];

    //array initialization
    for(int i = 0; i < length; i++)
    {
        myArray[i] = i;
    }

    print(myArray, length);

    //declaring a 2D array
    int TwoDArray[10][10];

    //array initialization
    for(int i = 0; i < 10; i++)
    {
        for(int j = 0; j < 10; j++)
        {
            TwoDArray[i][j] = i * j;
        }
    }

    print(TwoDArray, 10);

    //declaring a vector
    std::vector<int> myVector; // has 0 elements
    std::vector<int> newVector(10); //starts with 10, 0 initalized elements

    //see if a vector is empty
    std::cout << myVector.empty() << std::endl;

    //get the current size of the vector
    std::cout << myVector.size() << std::endl;

    //to add things to the vector at the end, use push_back
    myVector.push_back(42);
    myVector.push_back(99);

    //demonstrating that there is something there
    print(myVector);

    //we can access spaces in the vector (if they exist)
    std::cout << myVector[0] << std::endl;  //like strings, this isn't safe
    std::cout << myVector.at(0) << std::endl; //this is recommended

    //we can directly access the front and back elements of the vector
    std::cout << myVector.front() << std::endl;
    std::cout << myVector.back() << std::endl;

    //we can remove the back element
    myVector.pop_back();

    //we can clear the entire vector
    myVector.clear();

    /*
    There are some other vector functions but
    we need to learn about iterators before we can use them
    */

    return 0;
}

void print(int theArray[], int length)
{
    for(int i = 0; i < length; i++)
    {
        std::cout << theArray[i] << std::endl;
    }
}

void print(int theArray[][10], int length)
{
    for(int i = 0; i < 10; i++)
    {
        for(int j = 0; j < 10; j++)
        {
            std::cout << theArray[i][j];
            std::cout << "\t";
        }
        std::cout << std::endl;
    }
}

void print(std::vector<int> theVector)
{
    for(int i = 0; i < theVector.size(); i++)
    {
        std::cout << theVector.at(i) << std::endl;
    }
}
