#include <iostream>
//Example mostly taken from LearnCpp.com lesson 7.11
namespace Foo
{
    int DoSomething(int x, int y)
    {
        return x + y;
    }
}

namespace Goo
{
    int DoSomething(int x, int y)
    {
        return x - y;
    }
}

int main()
{
    /*
      The using keyword tells C++ to look in a namespace
      if it doesn't recognize something in the global namespace.
      It's considered bad practice to use it on a file level, but
      can be okay if you do it on a function level.
    */
    using namespace std;
    /*
      If we use one of these, it is okay.  If we use both,
      we'll get a namespace conflict.
   */
    //using namespace Foo;
    //using namespace Goo;
    cout << Foo::DoSomething(41, 1) << endl;
    cout << Goo::DoSomething(43, 1) << endl;
    return 0;
}

