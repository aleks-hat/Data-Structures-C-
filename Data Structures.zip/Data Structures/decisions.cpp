#include <iostream>

int main()
{
    int age = 0;
    char have_own_car = 'n';

    std::cout << "Enter your age: ";
    std::cin >> age;

    std::cout << "Do you have a car (y/n)?: ";
    std::cin >> have_own_car;

    if(age > 21 && have_own_car == 'y')
    {
        std::cout << "You are over 21 years old and own your own car\n";
    }
    else if(age > 21 && have_own_car == 'n')
    {
        std::cout << "You are over 21 years old and do NOT own your own car\n";
    }
    else if(age == 21 && have_own_car == 'y')
    {
        std::cout << "You are 21 years old and own your own car\n";
    }
    else if(age == 21 && have_own_car == 'n')
    {
        std::cout << "You are 21 years old and do NOT own your own car\n";
    }
    else if(age < 21 && have_own_car == 'y')
    {
        std::cout << "You are under 21 years old and own your own car\n";
    }
    else if(age > 21 && have_own_car == 'n')
    {
        std::cout << "You are under 21 years old and do NOT own your own car\n";
    }
    else
    {
        std::cout << "You did something wrong.\n";
    }

    int salary = 0;

    std::cout << "Please enter your salary: ";
    std::cin >> salary;

    if(salary > 50000 || age > 21)
    {
        std::cout << "You can join our club\n";
    }
    else
    {
        std::cout << "You can't join our club\n";
    }

    int number = 0;
    std::cout << "Enter a number, 1 to 5: ";
    std::cin >> number;

    switch(number)
    {
    case 1:
        std::cout << "One\n";
        break;
    case 2:
        std::cout << "Two\n";
        break;
    case 3:
        std::cout << "Three\n";
        break;
    case 4:
        std::cout << "Four\n";
        break;
    case 5:
        std::cout << "Five\n";
        break;
    default:
        std::cout << "You messed up.\n";
        break;
    }

    return 0;
}
