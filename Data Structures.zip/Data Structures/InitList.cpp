#include <iostream>

class Point
{
private:
    int x;
    int y;
public:
    /*
        The : syntax puts a value into the object before
        it is created.  The default parameters help us
        to shorten our code.  This constructor acts as
        a default constructor AND a parameterized constructor.
    */
    Point(int inX = 0, int inY = 0)
         :x(inX), y(inY)
    {
    }

   void printXY()
   {
      std::cout << x <<" " <<  y << std::endl;
   }
};

int main()
{
   Point firstPoint;
   Point secondPoint(5, 42);
   firstPoint.printXY();
   secondPoint.printXY();
   return 0;
}
