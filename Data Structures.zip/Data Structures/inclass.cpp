#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <cstdlib>


int main(){
    std::cout << "Hello World! " << std::endl;

    std::string name;
    std::cout << "What your name bb?" << std::endl;
    std::cin >> name;
    std::cout << "HELLO! " << name << std::endl;

    std::vector<int> myVector;
    srand(time(NULL));
    int randNum = rand() % 50 + 1;
    for (int i=0; i < randNum; i++){
        int n = rand() % 50 + 1;
        myVector.push_back(n);
        std::cout << myVector[i] << std::endl;
    }


}

   }
// big O of number 3 is probs O
