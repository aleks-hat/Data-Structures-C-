//Example modified from LearnCpp 7.7
#include <iostream>

/*
   Have to have parameter names and default values
   in the prototype.
*/

void print(int a = 0, int b = 0);

/*
    Not all of the parameters have to be default.
    But if you leave default values off, you have to start
    from the left.

    This would be okay:
    void print(int a, int b = 0);

    This would not be okay:
    void print(int a = 0, b);

    Also, the compiler would not be able to tell these two apart:
    void print(int a);
    void print(int a, int b = 0);
*/

int main()
{
   print(1, 2);
   print(1);
   print();
}

void print(int a, int b)
{
   std::cout << a << " " << b << std::endl;
}
