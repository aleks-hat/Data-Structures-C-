#include <iostream>

int main()
{
    int myInteger = 42;
    float myFloat = 42.42;
    double myDouble = 42.42;
}
