#include <iostream>
#include <ctime> //Using time as a random seed
#include <cstdlib> //getting random numbers

//C Style Randomness, we'll talk about C++ style later


//http://www.cplusplus.com/reference/cstdlib/rand/

int main()
{
    srand (time(NULL));  //uses the clock of the computer to seed the random number generator
    int randNum = rand() % 10 + 1; //gives a random number.

    std::cout << randNum << std::endl;

    return 0;
}
