/*
Lonnie Bowe
Dynamic Array Exercise Solution
CS 355

You can use this to study and/or review. Please ask questions.

I made some minor changes to make it easier, like defaulting the array to 0. 
*/

#include <iostream>

struct dynamicArray{
	int* array;
	int size; 	//the position for the next insert
	int maxSize; 	//resize when size == maxSize
};

//Create a new dynamic array. Takes a size parameter. Defaults to zero elements.
dynamicArray* createArray(int size = 0);

//Double the size of the array, copy over elements
void resize(dynamicArray*);

//Insert item at the end of the array
void insert(dynamicArray*, int);

//Print the array
void printArray(dynamicArray*);

//Free the memory used by the internal array
void freeArray(dynamicArray*);

int main(){
	dynamicArray* array = createArray();

	insert(array,1);
	printArray(array);
	
	insert(array,2);
	insert(array,3);
	printArray(array);

	std::cout << array->size << " " << array->maxSize << std::endl;

	//Free the memory
	freeArray(array);
	delete array;
	array = 0;

	return 0;
}

//Create a new dynamic array. Takes a size parameter. Defaults to zero elements.
dynamicArray* createArray(int size){
	dynamicArray* theArray = new dynamicArray;
	
	theArray->size = 0; //we haven't inserted; first insert will be at 0
	theArray->maxSize = size; //we have this many spaces to insert into
	
	if(size > 0){
		theArray->array = new int[size];
	}
	else{
		theArray->array = 0; //set to null
	}
	return theArray;
}

//Double the size of the array, copy over elements
void resize(dynamicArray* theArray){
	int* newArray = new int[theArray->maxSize*2];
	
	for(int i = 0; i < theArray->maxSize; i++){
		newArray[i] = theArray->array[i];
	}

	theArray->maxSize = theArray->maxSize * 2;
	delete theArray->array;
	theArray->array = newArray;
}

//Insert item at the end of the array
void insert(dynamicArray* theArray, int numToInsert){
	if(theArray->maxSize == 0){ //if we haven't created space yet
		theArray->array = new int[1];
		theArray->maxSize = 1;
	}
	else if(theArray->size == theArray->maxSize){ //no room
		resize(theArray);
	}

	//these lines need to happen, regardless
	theArray->array[theArray->size] = numToInsert;
	theArray->size++;
}

//Print the array
void printArray(dynamicArray* theArray){
	for(int i = 0; i < theArray->size; i++){
		std::cout << theArray->array[i] << std::endl;
	}
}

//Free the memory used by the internal array
void freeArray(dynamicArray* theArray){
	delete[] theArray->array;
}


