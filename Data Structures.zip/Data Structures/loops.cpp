#include <iostream>

int main()
{
    int counter = 0;

    std::cout << "While Loop" << std::endl;

    while(counter < 10)
    {
        std::cout << counter << std::endl;
        counter++;
    }

    std::cout << "Do While Loop" << std::endl;

    do
    {
        std::cout << counter << std::endl;
    }while(counter < 10);

    std::cout << "For Loop" << std::endl;

    for(int i = 0; i < 10; i++)
    {
        std::cout << i << std::endl;
    }

    return 0;
}
