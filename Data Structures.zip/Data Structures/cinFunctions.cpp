//Demonstrates functions and user input with cin

#include <iostream>

/*
Function prototypes
*/

int add(int, int);

/*
C++ offers something called function overloading.  It allows us to do
neat things.

We can now have functions with the same name with different return types
and different parameters
*/
double add(double, double);

/*
We can also have functions with the same name that take
a different number of parameters
*/
int add(int, int, int);

int main()
{

    std::cout << add(1, 1) << std::endl;
    std::cout << add(1.0, 1.0) << std::endl;
    std::cout << add(1, 1, 1) << std::endl;

    /*
    To get user input, we use cin
    cin doesn't require type specifications like scanf did
    cin seperates input based on whitespace.
    White space is space, tab, new line.
    */

    int x;
    double y;
    char z;

    std::cout << "Please enter an integer, a double, and a character with a space in between them" << std::endl;

    /*
    Notice that we use the opposite arrows than cout does.
    This is called the extraction operator.
    The way to remember which arrow to use is to think about
    which way the data is traveling.
    cout << something;  data is following from something into cout
    cin >> something;  data is following from cin into something
    */

    //You can take in multiple pieces of input this way.
    //They do not have to be the same data type.
    std::cin >> x >> y >> z;

    std::cout << "You entered: " << x << " " << y << " " << z << std::endl;

    return 0;
}

int add(int a, int b)
{
    return a + b;
}

double add(double a, double b)
{
    return a + b;
}

int add(int a, int b, int c)
{
    return a + b + c;
}
