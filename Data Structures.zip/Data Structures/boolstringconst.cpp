/*
Demonstrates the boolean and string types as well as const
*/

#include <iostream>
#include <string> //for the new string class

int main()
{
    /*
    we have a boolean type
    It can hold 0 or 1 or we can use the words true or false
    */

    bool tOrF = true;

    //We can establish data that we aren't allowed to change
    const double PI = 3.14159;

    //We have a string type with many methods
	std::string example = "Hello World";
    std::string example2 = "Hello World";

    //you can compare two strings.  The result is a boolean.
    //note that you need to wrap it in () for cout to know that you should evaluate first
	std::cout << (example == example2) << std::endl;

    //number of characters in the string
	std::cout << example.size() << std::endl;

    //number of bytes in the string
    std::cout << example.length() << std::endl;

    //access the first element of the string
    std::cout << example[0] << std::endl; //no boundary protection
    std::cout << example.at(0) << std::endl; //throws an exception if you run over, recommended

    //you can change strings this way too:
    example.at(0) = 'J';
    std::cout << example << std::endl;

    //clear a string, check to see if it's empty
    example.clear();
    std::cout << example.empty() << std::endl; //returns true if empty

    //append can add multiple characters to the end of an existing string
    example.append("Hello World");
    std::cout << example << std::endl;

    //push_back adds one character at a time
    example.push_back('!');
    std::cout << example << std::endl;

    //You can also use the + operator for concatenation
    example = example + "!!!!!!";
    std::cout << example << std::endl;

    //you can insert characters into a string at different positions
    example.insert(6, "there ");
    std::cout << example << std::endl;

    //you can delete characters from a string
    example.erase(0,1); //start at 0, erase 1 character
    std::cout << example << std::endl;

    //you can get parts of a string
    std::string partOfString = example.substr(0,4); //starting position, how many characters you want
    std::cout << partOfString << std::endl;

	/*
	You can use cin to read a string, but it will only read until it hits whitespace
	Whitespace is a space, a tab, a newline
	*/
	std::cout << "Please enter a string" << std::endl;
	std::cin >> example;
	std::cout << "You entered " << example << std::endl;
        std::cin.ignore(10000, '\n');
	/*
	getline will read an entire line until it hits a newline
	notice that it takes a stream to read from and a variable to store the info in
	*/
    std::cout << "Please enter a string" << std::endl;
	std::getline( std::cin, example);
	std::cout << "You entered " << example << std::endl;

    return 0;
}
