/*
Your Names Here
Linked List Exercise
CS 355
Your Tasks:
	Finish the append method, write a prepend method
	Think about what errors could occur and what to do about it.
*/

#include <iostream>

struct node{
	int info;
	node* next;
};

struct list{
	node* head;
};

//Initialize and return an empty list
list* createList();

//Add an item to the end of the list
void append(list*&, int);

//Print the list
void printList(list*);

//Free the list
void freeList(list*&);

int main(){
	list* myList = createList();
	append(myList, 42);
	printList(myList);

	//Free the memory
	freeList(myList);
	delete myList;
	myList = 0;

	return 0;
}

//Initialize and return an empty list
list* createList(){
	list* newList = new list;
	newList->head = 0;
	return newList;
}

//Add an item to the end of the list
void append(list*& theList, int num){
	if(theList->head == 0){
		theList->head = new node;

		theList->head->info = num;
		theList->head->next = 0;
	}
	else{
		//Fill this in
	}
}

//Print the list
void printList(list* theList){
	node* current = theList->head;
	while(current != 0){
		std::cout << current->info << std::endl;
		current = current->next;
	}
}

//Free the list
void freeList(list*& theList){
	while(theList->head != 0){
		node* temp = theList->head->next;
		delete theList->head;
		theList->head = temp;
	}
}
